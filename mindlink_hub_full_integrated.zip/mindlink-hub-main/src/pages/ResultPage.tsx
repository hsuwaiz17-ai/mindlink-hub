
import ResultActions from "../components/ResultActions";

export default function ResultPage() {
  const result = sessionStorage.getItem("result") || "";
  return (
    <div>
      <ResultActions />
      <div id="result-content">
        <pre>{result}</pre>
      </div>
    </div>
  );
}
