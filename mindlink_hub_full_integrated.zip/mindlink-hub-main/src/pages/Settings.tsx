
export default function Settings() {
  return (
    <div>
      <div>
        <strong>App Owner</strong>
        <div>Arkar Kyaw (MIIT)</div>
        <div>Hsu Wai Zin (UCSMG)</div>
      </div>
      <button>Sign Out</button>
    </div>
  );
}
