
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { generateResult } from "../services/gemini";

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const navigate = useNavigate();

  async function handleGenerate() {
    const result = await generateResult(prompt);
    sessionStorage.setItem("result", result);
    navigate("/result");
  }

  return (
    <div>
      <textarea value={prompt} onChange={e => setPrompt(e.target.value)} />
      <button onClick={handleGenerate}>Generate Result</button>
    </div>
  );
}
