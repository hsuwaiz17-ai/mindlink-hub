
import jsPDF from "jspdf";

export function exportPDF(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  const pdf = new jsPDF();
  pdf.html(el, {
    callback: () => pdf.save("result.pdf"),
    x: 10,
    y: 10
  });
}
