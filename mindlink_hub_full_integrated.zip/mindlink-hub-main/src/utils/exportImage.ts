
import html2canvas from "html2canvas";

export async function exportImage(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  const canvas = await html2canvas(el);
  const link = document.createElement("a");
  link.href = canvas.toDataURL("image/png");
  link.download = "result.png";
  link.click();
}
