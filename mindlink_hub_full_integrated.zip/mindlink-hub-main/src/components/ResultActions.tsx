
import { exportPDF } from "../utils/exportPdf";
import { exportImage } from "../utils/exportImage";

export default function ResultActions() {
  return (
    <div style={{ display: "flex", gap: 12 }}>
      <button onClick={() => exportImage("result-content")}>Image</button>
      <button onClick={() => exportPDF("result-content")}>PDF</button>
    </div>
  );
}
