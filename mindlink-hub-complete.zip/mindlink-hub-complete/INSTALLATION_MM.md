# MindLink Hub - Installation Guide (မြန်မာလို)

## လိုအပ်ချက်များ (Prerequisites)

ဒီ project ကို run ဖို့ အောက်ပါ software တွေ လိုအပ်ပါတယ်:

1. **Node.js** (version 18 သို့မဟုတ် အထက်)
   - Download: https://nodejs.org/

2. **Supabase Account**
   - Sign up: https://supabase.com/

3. **Google Gemini API Key**
   - Get API key: https://makersuite.google.com/app/apikey

## အဆင့်ဆင့် Installation လုပ်နည်း

### အဆင့် 1: Project ကို Download လုပ်ရန်

```bash
# GitHub မှ clone လုပ်ခြင်း
git clone https://github.com/hsuwaiz17-ai/mindlink-hub.git
cd mindlink-hub

# သို့မဟုတ် ZIP file ကို extract လုပ်ပြီး folder ထဲဝင်ပါ
```

### အဆင့် 2: Dependencies များ Install လုပ်ရန်

```bash
# npm သုံးပါက
npm install

# bun သုံးပါက
bun install
```

### အဆင့် 3: Supabase Setup လုပ်ရန်

#### 3.1. Supabase Project ဖန်တီးခြင်း
1. https://supabase.com မှာ login ဝင်ပါ
2. "New Project" နှိပ်ပါ
3. Project name, Database password ထည့်ပါ
4. Region ရွေးပါ (Singapore အကောင်းဆုံး)

#### 3.2. Database Tables ဖန်တီးခြင်း

**SQL Editor** သို့သွားပြီး အောက်ပါ queries တွေ run ပါ:

```sql
-- profiles table
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text,
  avatar_url text,
  bio text,
  username text unique,
  updated_at timestamp with time zone default now()
);

-- Enable Row Level Security
alter table profiles enable row level security;

-- Policies
create policy "Public profiles are viewable by everyone."
  on profiles for select
  using ( true );

create policy "Users can insert their own profile."
  on profiles for insert
  with check ( auth.uid() = id );

create policy "Users can update own profile."
  on profiles for update
  using ( auth.uid() = id );

-- history table
create table history (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references auth.users on delete cascade not null,
  title text,
  input_text text,
  result_text text,
  mode text,
  language text,
  created_at timestamp with time zone default now()
);

-- Enable Row Level Security
alter table history enable row level security;

-- Policies
create policy "Users can view their own history."
  on history for select
  using ( auth.uid() = user_id );

create policy "Users can insert their own history."
  on history for insert
  with check ( auth.uid() = user_id );

create policy "Users can update their own history."
  on history for update
  using ( auth.uid() = user_id );

create policy "Users can delete their own history."
  on history for delete
  using ( auth.uid() = user_id );

-- settings table (optional)
create table settings (
  id uuid default uuid_generate_v4() primary key,
  gemini_api_key text,
  created_at timestamp with time zone default now()
);
```

#### 3.3. Storage Bucket ဖန်တီးခြင်း

1. Supabase Dashboard မှာ **Storage** သို့သွားပါ
2. **New Bucket** နှိပ်ပါ
3. Bucket name: `avatars`
4. Public bucket: **Yes** ရွေးပါ
5. File size limit: `2MB`
6. **Create bucket** နှိပ်ပါ

#### 3.4. Storage Policies သတ်မှတ်ခြင်း

```sql
-- Allow users to upload their own avatars
create policy "Users can upload their own avatar."
  on storage.objects for insert
  with check (
    bucket_id = 'avatars' 
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- Allow users to update their own avatars
create policy "Users can update their own avatar."
  on storage.objects for update
  using (
    bucket_id = 'avatars' 
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- Allow anyone to view avatars
create policy "Anyone can view avatars."
  on storage.objects for select
  using ( bucket_id = 'avatars' );
```

### အဆင့် 4: Environment Variables Setup

1. `.env.example` file ကို copy လုပ်ပြီး `.env` အဖြစ် rename လုပ်ပါ:

```bash
cp .env.example .env
```

2. `.env` file ကို ဖွင့်ပြီး သင့်ရဲ့ Gemini API key ထည့်ပါ:

```env
VITE_GEMINI_API_KEY=your_actual_gemini_api_key_here
```

**Gemini API Key ရယူနည်း:**
1. https://makersuite.google.com/app/apikey သို့သွားပါ
2. Google account နဲ့ login ဝင်ပါ
3. **Create API Key** နှိပ်ပါ
4. API key ကို copy လုပ်ပြီး `.env` file မှာ paste လုပ်ပါ

### အဆင့် 5: Supabase Credentials Update လုပ်ရန်

`src/integrations/supabase/client.ts` file မှာ သင့်ရဲ့ Supabase credentials တွေ ထည့်ပေးပါ:

```typescript
const SUPABASE_URL = "your_supabase_project_url";
const SUPABASE_PUBLISHABLE_KEY = "your_supabase_anon_key";
```

**Credentials ရှာနည်း:**
1. Supabase Dashboard → **Settings** → **API**
2. **Project URL** နဲ့ **anon/public** key ကို copy လုပ်ပါ

### အဆင့် 6: Development Server Run ခြင်း

```bash
# Development mode
npm run dev

# သို့မဟုတ်
bun dev
```

Browser မှာ http://localhost:8080 ကို ဖွင့်ပါ

### အဆင့် 7: Production Build လုပ်ခြင်း

```bash
# Build for production
npm run build

# သို့မဟုတ်
bun run build
```

Build လုပ်ပြီးသွားရင် `dist` folder မှာ files တွေ ရှိနေမှာ ဖြစ်ပါတယ်။

## အသုံးပြုနည်း

### Account ဖန်တီးခြင်း

1. App ကို ဖွင့်ပါ
2. **Create Account** နှိပ်ပါ
3. Email နဲ့ Password ထည့်ပါ
4. **Sign Up** နှိပ်ပါ
5. Email စစ်ကြည့်ပြီး verify link ကို နှိပ်ပါ

### Features များ အသုံးပြုခြင်း

#### 1. Content Summarize လုပ်ခြင်း
- Input method ရွေးပါ (Camera/Image/Text/File)
- Content ထည့်ပါ
- Result language ရွေးပါ
- **Summarize** action ရွေးပါ
- **Process** နှိပ်ပါ

#### 2. Answer ရှာခြင်း
- Question သို့မဟုတ် content ထည့်ပါ
- **Find Answer** ရွေးပါ
- Result ထွက်လာမှာပါ

#### 3. Paraphrase လုပ်ခြင်း
- Text ထည့်ပါ
- **Paraphrase** ရွေးပါ
- အသစ်ပြန်ရေးထားတဲ့ text ရမှာပါ

#### 4. Theory Explain လုပ်ခြင်း
- Complex concept ထည့်ပါ
- **Explain Theory** ရွေးပါ
- အသေးစိတ် explanation ရမှာပါ

### Result များ Save လုပ်ခြင်း

Result ထွက်လာပြီဆိုရင်:
- **Image** button - PNG image အဖြစ် save လုပ်မှာပါ
- **PDF** button - PDF file အဖြစ် save လုပ်မှာပါ

## Troubleshooting

### API Key Errors

```
Error: API Key missing!
```

**Solution:** `.env` file မှာ `VITE_GEMINI_API_KEY` ရှိမရှိ စစ်ပါ

### Supabase Connection Errors

```
Error: Invalid API key
```

**Solution:** `src/integrations/supabase/client.ts` မှာ URL နဲ့ key တွေ မှန်မမှန် စစ်ပါ

### Database Errors

```
Error: relation "profiles" does not exist
```

**Solution:** SQL queries တွေ အားလုံး run ပြီးပြီလား စစ်ပါ

## အကူအညီလိုရင်

- GitHub Issues: https://github.com/hsuwaiz17-ai/mindlink-hub/issues
- Email: arkarkyaw@example.com, hsuwaizin@example.com

## နောက်ထပ် Resources

- [Supabase Documentation](https://supabase.com/docs)
- [Gemini API Documentation](https://ai.google.dev/docs)
- [React Documentation](https://react.dev/)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)

---

© 2025 MindLink - Arkar Kyaw (MIIT) & Hsu Wai Zin (UCSMG)
