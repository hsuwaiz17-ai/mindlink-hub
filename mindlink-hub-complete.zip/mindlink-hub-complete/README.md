# MindLink Hub

MindLink is an intelligent AI-powered application that helps you:
- **Summarize** content from various sources
- **Find answers** to questions
- **Paraphrase** text in different styles
- **Explain theories** and complex concepts

## Features

### 🎯 Multiple Input Methods
- **Camera Scan**: Capture text using your device camera
- **Image Upload**: Extract text from images
- **Text Input**: Direct text entry
- **File Upload**: Support for .txt, .doc, .docx, .pdf files

### 🌍 Multi-Language Support
- English, မြန်မာ (Myanmar), 日本語 (Japanese), 한국어 (Korean)
- 中文 (Chinese), ไทย (Thai), Tiếng Việt (Vietnamese)
- Español (Spanish), Français (French), Deutsch (German)
- हिन्दी (Hindi), Indonesia (Indonesian)

### 🎨 Customizable Interface
- Dark/Light mode
- Adjustable font sizes (Small, Medium, Large)
- Responsive design for all devices

### 🔐 Security & Privacy
- Secure authentication with Supabase
- Password reset functionality
- User profile management

### 📝 Smart Actions
- **Summarize**: Get concise summaries of long content
- **Answer**: Find answers to specific questions
- **Paraphrase**: Rewrite text in different ways
- **Explain**: Get detailed explanations of complex topics

### 💾 Export Options
- Save results as **Images** (PNG)
- Save results as **PDF** (high quality, preserves formatting)

### 📚 History Management
- Search through past queries
- Edit titles for easy reference
- Delete unwanted entries
- View detailed input/output

## Tech Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **UI Components**: Radix UI
- **Routing**: React Router v6
- **State Management**: TanStack Query
- **Authentication**: Supabase Auth
- **Database**: Supabase (PostgreSQL)
- **AI**: Google Gemini API
- **PDF Generation**: jsPDF
- **Image Capture**: html2canvas
- **Internationalization**: i18next

## Getting Started

### Prerequisites
- Node.js 18+ or Bun
- Supabase account
- Google Gemini API key

### Installation

1. Clone the repository:
\`\`\`bash
git clone https://github.com/hsuwaiz17-ai/mindlink-hub.git
cd mindlink-hub
\`\`\`

2. Install dependencies:
\`\`\`bash
npm install
# or
bun install
\`\`\`

3. Create a \`.env\` file:
\`\`\`bash
cp .env.example .env
\`\`\`

4. Add your Gemini API key to \`.env\`:
\`\`\`
VITE_GEMINI_API_KEY=your_api_key_here
\`\`\`

5. Run the development server:
\`\`\`bash
npm run dev
# or
bun dev
\`\`\`

6. Open [http://localhost:8080](http://localhost:8080)

## Supabase Setup

### Database Tables

#### profiles
\`\`\`sql
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text,
  avatar_url text,
  bio text,
  username text unique,
  updated_at timestamp with time zone
);
\`\`\`

#### history
\`\`\`sql
create table history (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references auth.users on delete cascade not null,
  title text,
  input_text text,
  result_text text,
  mode text,
  language text,
  created_at timestamp with time zone default now()
);
\`\`\`

#### settings (optional, for storing Gemini API key)
\`\`\`sql
create table settings (
  id uuid default uuid_generate_v4() primary key,
  gemini_api_key text,
  created_at timestamp with time zone default now()
);
\`\`\`

### Storage Buckets

Create a storage bucket for avatars:
- Bucket name: \`avatars\`
- Public: Yes
- File size limit: 2MB

## Build for Production

\`\`\`bash
npm run build
# or
bun run build
\`\`\`

The built files will be in the \`dist\` directory.

## Developers

- **Arkar Kyaw** (MIIT)
- **Hsu Wai Zin** (UCSMG)

## License

© 2025 MindLink. All rights reserved.

## Support

For support, please contact the developers or open an issue on GitHub.
