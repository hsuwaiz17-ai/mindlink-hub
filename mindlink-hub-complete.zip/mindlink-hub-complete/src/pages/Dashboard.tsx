import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { 
  Camera, Image as ImageIcon, FileText, File, 
  History, Settings, User, LogOut, Save, Download 
} from 'lucide-react';
import { toast } from 'sonner';
import { generateAIContent, extractTextFromImage } from '@/lib/gemini';
import { readFileAsText, readFileAsBase64 } from '@/lib/utils';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

type InputMethod = 'camera' | 'image' | 'text' | 'file' | null;
type ActionMode = 'summarize' | 'answer' | 'paraphrase' | 'explain' | null;

export default function Dashboard() {
  const [user, setUser] = useState<any>(null);
  const [inputMethod, setInputMethod] = useState<InputMethod>(null);
  const [actionMode, setActionMode] = useState<ActionMode>(null);
  const [inputContent, setInputContent] = useState('');
  const [resultLanguage, setResultLanguage] = useState('en');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    checkUser();
  }, []);

  const checkUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate('/auth');
    } else {
      setUser(user);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/auth');
  };

  // Handle Camera Input
  const handleCameraCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      const base64 = await readFileAsBase64(file);
      const extractedText = await extractTextFromImage(base64);
      setInputContent(extractedText);
      toast.success('Text extracted from camera!');
    } catch (error: any) {
      toast.error('Failed to extract text from image');
    } finally {
      setLoading(false);
    }
  };

  // Handle Image Upload
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      const base64 = await readFileAsBase64(file);
      const extractedText = await extractTextFromImage(base64);
      setInputContent(extractedText);
      toast.success('Text extracted from image!');
    } catch (error: any) {
      toast.error('Failed to extract text from image');
    } finally {
      setLoading(false);
    }
  };

  // Handle File Upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      const text = await readFileAsText(file);
      setInputContent(text);
      toast.success('File content loaded!');
    } catch (error: any) {
      toast.error('Failed to read file');
    } finally {
      setLoading(false);
    }
  };

  // Process Content
  const handleProcessContent = async () => {
    if (!inputContent.trim()) {
      toast.error('Please provide some input content');
      return;
    }

    if (!actionMode) {
      toast.error('Please select an action mode');
      return;
    }

    setLoading(true);
    try {
      const generatedResult = await generateAIContent(inputContent, actionMode, resultLanguage);
      setResult(generatedResult);
      
      // Save to history
      await supabase.from('history').insert({
        user_id: user.id,
        input_text: inputContent,
        result_text: generatedResult,
        mode: actionMode,
        language: resultLanguage,
        title: inputContent.substring(0, 50) + '...'
      });
      
      toast.success(t('processingComplete'));
    } catch (error: any) {
      toast.error('Failed to process content');
    } finally {
      setLoading(false);
    }
  };

  // Save as Image
  const handleSaveAsImage = async () => {
    if (!resultRef.current) return;

    try {
      const canvas = await html2canvas(resultRef.current);
      const link = document.createElement('a');
      link.download = `mindlink-result-${Date.now()}.png`;
      link.href = canvas.toDataURL();
      link.click();
      toast.success('Saved as image!');
    } catch (error) {
      toast.error('Failed to save as image');
    }
  };

  // Save as PDF
  const handleSaveAsPDF = async () => {
    if (!resultRef.current) return;

    try {
      const canvas = await html2canvas(resultRef.current, {
        scale: 2,
        useCORS: true,
        logging: false,
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      const imgWidth = 210;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
      pdf.save(`mindlink-result-${Date.now()}.pdf`);
      toast.success('Saved as PDF!');
    } catch (error) {
      toast.error('Failed to save as PDF');
    }
  };

  const availableLanguages = [
    { code: 'en', name: 'English' },
    { code: 'my', name: 'မြန်မာ' },
    { code: 'ja', name: '日本語' },
    { code: 'ko', name: '한국어' },
    { code: 'zh', name: '中文' },
    { code: 'th', name: 'ไทย' },
    { code: 'vi', name: 'Tiếng Việt' },
    { code: 'es', name: 'Español' },
    { code: 'fr', name: 'Français' },
    { code: 'de', name: 'Deutsch' },
    { code: 'hi', name: 'हिन्दी' },
    { code: 'id', name: 'Indonesia' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-indigo-950 dark:to-purple-950">
      {/* Header */}
      <header className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            MindLink
          </h1>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/history')}
              className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
            >
              <History className="w-5 h-5" />
              <span className="hidden sm:inline">{t('history')}</span>
            </button>
            
            <div className="relative">
              <button
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center text-white"
              >
                <User className="w-5 h-5" />
              </button>
              
              {showProfileMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 py-2 z-50">
                  <button
                    onClick={() => { navigate('/profile'); setShowProfileMenu(false); }}
                    className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2"
                  >
                    <User className="w-4 h-4" />
                    {t('profile')}
                  </button>
                  <button
                    onClick={() => { navigate('/settings'); setShowProfileMenu(false); }}
                    className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2"
                  >
                    <Settings className="w-4 h-4" />
                    {t('settings')}
                  </button>
                  <button
                    onClick={handleSignOut}
                    className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2 text-red-600"
                  >
                    <LogOut className="w-4 h-4" />
                    {t('signOut')}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-6">
          {/* Input Method Selection */}
          <div className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
            <h2 className="text-lg font-semibold mb-4">{t('selectInputMethod')}</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <button
                onClick={() => { setInputMethod('camera'); cameraInputRef.current?.click(); }}
                className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${
                  inputMethod === 'camera'
                    ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-300 hover:border-blue-400'
                }`}
              >
                <Camera className="w-8 h-8 mb-2" />
                <span className="text-sm font-medium">{t('scan')}</span>
              </button>

              <button
                onClick={() => { setInputMethod('image'); imageInputRef.current?.click(); }}
                className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${
                  inputMethod === 'image'
                    ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-300 hover:border-blue-400'
                }`}
              >
                <ImageIcon className="w-8 h-8 mb-2" />
                <span className="text-sm font-medium">{t('image')}</span>
              </button>

              <button
                onClick={() => setInputMethod('text')}
                className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${
                  inputMethod === 'text'
                    ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-300 hover:border-blue-400'
                }`}
              >
                <FileText className="w-8 h-8 mb-2" />
                <span className="text-sm font-medium">{t('text')}</span>
              </button>

              <button
                onClick={() => { setInputMethod('file'); fileInputRef.current?.click(); }}
                className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${
                  inputMethod === 'file'
                    ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-300 hover:border-blue-400'
                }`}
              >
                <File className="w-8 h-8 mb-2" />
                <span className="text-sm font-medium">{t('file')}</span>
              </button>
            </div>

            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleCameraCapture}
              className="hidden"
            />
            <input
              ref={imageInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
            <input
              ref={fileInputRef}
              type="file"
              accept=".txt,.doc,.docx,.pdf"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>

          {/* Text Input Area */}
          {inputMethod === 'text' && (
            <div className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
              <textarea
                value={inputContent}
                onChange={(e) => setInputContent(e.target.value)}
                placeholder="Enter your text here..."
                className="w-full h-40 p-4 bg-white/50 dark:bg-gray-800/50 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none resize-none"
              />
            </div>
          )}

          {/* Show content if loaded from image/file */}
          {inputContent && inputMethod !== 'text' && (
            <div className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
              <h3 className="font-semibold mb-2">Extracted Content:</h3>
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg max-h-60 overflow-y-auto">
                {inputContent}
              </div>
            </div>
          )}

          {/* Result Language Selection */}
          {inputContent && (
            <div className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
              <h2 className="text-lg font-semibold mb-4">{t('resultLanguage')}</h2>
              <select
                value={resultLanguage}
                onChange={(e) => setResultLanguage(e.target.value)}
                className="w-full p-3 bg-white/50 dark:bg-gray-800/50 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none"
              >
                {availableLanguages.map((lang) => (
                  <option key={lang.code} value={lang.code}>
                    {lang.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Action Buttons */}
          {inputContent && (
            <div className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
              <h2 className="text-lg font-semibold mb-4">Select Action</h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <button
                  onClick={() => setActionMode('summarize')}
                  className={`p-4 rounded-xl border-2 transition-all font-medium ${
                    actionMode === 'summarize'
                      ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20 text-blue-600'
                      : 'border-gray-300 hover:border-blue-400'
                  }`}
                >
                  {t('summarize')}
                </button>

                <button
                  onClick={() => setActionMode('answer')}
                  className={`p-4 rounded-xl border-2 transition-all font-medium ${
                    actionMode === 'answer'
                      ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20 text-blue-600'
                      : 'border-gray-300 hover:border-blue-400'
                  }`}
                >
                  {t('answer')}
                </button>

                <button
                  onClick={() => setActionMode('paraphrase')}
                  className={`p-4 rounded-xl border-2 transition-all font-medium ${
                    actionMode === 'paraphrase'
                      ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20 text-blue-600'
                      : 'border-gray-300 hover:border-blue-400'
                  }`}
                >
                  {t('paraphrase')}
                </button>

                <button
                  onClick={() => setActionMode('explain')}
                  className={`p-4 rounded-xl border-2 transition-all font-medium ${
                    actionMode === 'explain'
                      ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20 text-blue-600'
                      : 'border-gray-300 hover:border-blue-400'
                  }`}
                >
                  {t('explain')}
                </button>
              </div>

              <button
                onClick={handleProcessContent}
                disabled={loading || !actionMode}
                className="w-full mt-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? t('loading') : 'Process'}
              </button>
            </div>
          )}

          {/* Result */}
          {result && (
            <div className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">{t('result')}</h2>
                <div className="flex gap-2">
                  <button
                    onClick={handleSaveAsImage}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Image
                  </button>
                  <button
                    onClick={handleSaveAsPDF}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    PDF
                  </button>
                </div>
              </div>
              
              <div 
                ref={resultRef}
                className="p-6 bg-white dark:bg-gray-800 rounded-xl prose dark:prose-invert max-w-none"
              >
                {result}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
