import { createClient } from '@supabase/supabase-js';
import type { Database } from './types';

const SUPABASE_URL = "https://tnqjltxxxptdelqylyyk.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRucWpsdHh4eHB0ZGVscXlseXlrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg5NzExOTAsImV4cCI6MjA4NDU0NzE5MH0.475KvapITbsZcWeZnrRIH21L6ZX2fqqdL3DrCMjtOZw";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    storage: localStorage,
    persistSession: true,
    autoRefreshToken: true,
  }
});
