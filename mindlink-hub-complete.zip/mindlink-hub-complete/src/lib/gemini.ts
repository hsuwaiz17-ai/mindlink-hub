import { GoogleGenerativeAI } from "@google/generative-ai";
import { supabase } from "@/integrations/supabase/client";

// Get Gemini API key from Supabase or environment variable
const getApiKey = async () => {
  try {
    // Try to get from Supabase first
    const { data, error } = await supabase
      .from('settings')
      .select('gemini_api_key')
      .single();
    
    if (!error && data?.gemini_api_key) {
      return data.gemini_api_key;
    }
  } catch (err) {
    console.log('Using environment API key');
  }
  
  // Fallback to environment variable
  return import.meta.env.VITE_GEMINI_API_KEY;
};

let genAI: GoogleGenerativeAI | null = null;

const initializeGenAI = async () => {
  if (!genAI) {
    const apiKey = await getApiKey();
    if (!apiKey) {
      throw new Error("API Key missing! Please configure Gemini API key.");
    }
    genAI = new GoogleGenerativeAI(apiKey);
  }
  return genAI;
};

// Main function to generate AI content with different modes
export const generateAIContent = async (
  content: string,
  mode: 'summarize' | 'answer' | 'paraphrase' | 'explain',
  language: string = 'en'
) => {
  const ai = await initializeGenAI();
  const model = ai.getGenerativeModel({ model: "gemini-1.5-flash" });
  
  let prompt = '';
  
  const languageNames: { [key: string]: string } = {
    'en': 'English',
    'my': 'Myanmar (Burmese)',
    'ja': 'Japanese',
    'ko': 'Korean',
    'zh': 'Chinese',
    'th': 'Thai',
    'vi': 'Vietnamese',
    'es': 'Spanish',
    'fr': 'French',
    'de': 'German',
    'hi': 'Hindi',
    'id': 'Indonesian',
  };
  
  const targetLanguage = languageNames[language] || 'English';
  
  switch (mode) {
    case 'summarize':
      prompt = `Please provide a comprehensive summary of the following content in ${targetLanguage}. Make it clear and concise:\n\n${content}`;
      break;
    case 'answer':
      prompt = `Please analyze the following content and provide detailed answers to any questions or find key information in ${targetLanguage}:\n\n${content}`;
      break;
    case 'paraphrase':
      prompt = `Please paraphrase the following content in ${targetLanguage}, maintaining the original meaning but using different words and sentence structures:\n\n${content}`;
      break;
    case 'explain':
      prompt = `Please explain any theories, concepts, or complex ideas in the following content in ${targetLanguage}. Make the explanation clear and easy to understand:\n\n${content}`;
      break;
    default:
      prompt = content;
  }
  
  const result = await model.generateContent(prompt);
  const response = await result.response;
  return response.text();
};

// Function to extract text from image
export const extractTextFromImage = async (imageData: string) => {
  const ai = await initializeGenAI();
  const model = ai.getGenerativeModel({ model: "gemini-1.5-flash" });
  
  // Remove data URL prefix if present
  const base64Data = imageData.replace(/^data:image\/\w+;base64,/, '');
  
  const imageParts = [
    {
      inlineData: {
        data: base64Data,
        mimeType: "image/jpeg"
      }
    }
  ];
  
  const prompt = "Extract all text from this image. If there are mathematical formulas, equations, or diagrams, describe them clearly. Return only the extracted text.";
  
  const result = await model.generateContent([prompt, ...imageParts]);
  const response = await result.response;
  return response.text();
};

// Function to process file content
export const processFileContent = async (
  fileContent: string,
  fileName: string,
  mode: 'summarize' | 'answer' | 'paraphrase' | 'explain',
  language: string = 'en'
) => {
  const prompt = `File: ${fileName}\n\nContent:\n${fileContent}`;
  return await generateAIContent(prompt, mode, language);
};
