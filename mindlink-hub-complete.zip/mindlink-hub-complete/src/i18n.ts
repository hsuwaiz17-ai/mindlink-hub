import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  // English
  en: {
    translation: {
      // Auth
      "welcome": "Welcome from MindLink",
      "email": "Email",
      "password": "Password",
      "forgotPassword": "Forgot Password?",
      "signIn": "Sign In",
      "signUp": "Sign Up",
      "createAccount": "Create Account",
      "alreadyHaveAccount": "Already have an account?",
      "dontHaveAccount": "Don't have an account?",
      
      // Dashboard
      "scan": "Scan",
      "image": "Image",
      "text": "Text",
      "file": "File",
      "selectInputMethod": "Select Input Method",
      "resultLanguage": "Result Language",
      "selectLanguage": "Select Language",
      
      // Actions
      "summarize": "Summarize",
      "answer": "Find Answer",
      "paraphrase": "Paraphrase",
      "explain": "Explain Theory",
      "result": "Result",
      "saveAsImage": "Save as Image",
      "saveAsPDF": "Save as PDF",
      
      // Navigation
      "history": "History",
      "settings": "Settings",
      "profile": "Profile",
      "signOut": "Sign Out",
      
      // Profile
      "editProfile": "Edit Profile",
      "uploadImage": "Upload Image",
      "bio": "Bio",
      "enterBio": "Enter your bio...",
      "saveChanges": "Save Changes",
      
      // Settings
      "appearance": "Appearance",
      "darkMode": "Dark Mode",
      "lightMode": "Light Mode",
      "fontSize": "Font Size",
      "small": "Small",
      "medium": "Medium",
      "large": "Large",
      "security": "Security & Privacy",
      "changePassword": "Change Password",
      "language": "App Language",
      "about": "About App",
      
      // About
      "aboutDescription": "MindLink is an intelligent AI-powered application that helps you summarize content, find answers, paraphrase text, and explain theories. It supports multiple input methods including camera scanning, image upload, text input, and file upload.",
      "developers": "Developers",
      "version": "Version",
      
      // History
      "searchHistory": "Search History",
      "noHistory": "No history yet",
      "delete": "Delete",
      "renameTitle": "Rename Title",
      
      // Common
      "cancel": "Cancel",
      "confirm": "Confirm",
      "save": "Save",
      "edit": "Edit",
      "delete": "Delete",
      "loading": "Loading...",
      "error": "Error",
      "success": "Success",
      "pleaseWait": "Please wait...",
      "uploadFailed": "Upload failed",
      "processingComplete": "Processing complete",
    }
  },
  
  // Myanmar (Burmese)
  my: {
    translation: {
      // Auth
      "welcome": "MindLink မှ ကြိုဆိုပါသည်",
      "email": "အီးမေးလ်",
      "password": "စကားဝှက်",
      "forgotPassword": "စကားဝှက်မေ့နေပါသလား?",
      "signIn": "ဝင်ရောက်ရန်",
      "signUp": "အကောင့်ဖွင့်ရန်",
      "createAccount": "အကောင့်အသစ်ဖန်တီးရန်",
      "alreadyHaveAccount": "အကောင့်ရှိပြီးသားလား?",
      "dontHaveAccount": "အကောင့်မရှိသေးဘူးလား?",
      
      // Dashboard
      "scan": "စကန်ဖတ်ရန်",
      "image": "ပုံ",
      "text": "စာသား",
      "file": "ဖိုင်",
      "selectInputMethod": "ထည့်သွင်းမည့်နည်းလမ်းရွေးရန်",
      "resultLanguage": "ရလဒ်ဘာသာစကား",
      "selectLanguage": "ဘာသာစကားရွေးရန်",
      
      // Actions
      "summarize": "အနှစ်ချုပ်",
      "answer": "အဖြေရှာရန်",
      "paraphrase": "စကားပြေပြန်ဆိုရန်",
      "explain": "သီအိုရီရှင်းပြရန်",
      "result": "ရလဒ်",
      "saveAsImage": "ပုံအဖြစ်သိမ်းရန်",
      "saveAsPDF": "PDF အဖြစ်သိမ်းရန်",
      
      // Navigation
      "history": "မှတ်တမ်း",
      "settings": "ဆက်တင်များ",
      "profile": "ပရိုဖိုင်",
      "signOut": "ထွက်ရန်",
      
      // Profile
      "editProfile": "ပရိုဖိုင်ပြင်ဆင်ရန်",
      "uploadImage": "ပုံတင်ရန်",
      "bio": "အကြောင်းအရာ",
      "enterBio": "သင့်အကြောင်းရေးပါ...",
      "saveChanges": "ပြောင်းလဲမှုများသိမ်းရန်",
      
      // Settings
      "appearance": "အသွင်အပြင်",
      "darkMode": "အမှောင်မုဒ်",
      "lightMode": "အလင်းမုဒ်",
      "fontSize": "စာလုံးအရွယ်အစား",
      "small": "သေး",
      "medium": "အလတ်",
      "large": "ကြီး",
      "security": "လုံခြုံရေးနှင့်ကိုယ်ရေးကိုယ်တာ",
      "changePassword": "စကားဝှက်ပြောင်းရန်",
      "language": "အက်ပ်ဘာသာစကား",
      "about": "အက်ပ်အကြောင်း",
      
      // About
      "aboutDescription": "MindLink သည် AI နည်းပညာဖြင့် အကြောင်းအရာများကို အနှစ်ချုပ်ပေးခြင်း၊ အဖြေရှာပေးခြင်း၊ စကားပြန်ဆိုပေးခြင်းနှင့် သီအိုရီများ ရှင်းပြပေးနိုင်သော စမတ်အက်ပ်တစ်ခုဖြစ်ပါသည်။ ကင်မရာစကန်၊ ပုံတင်ခြင်း၊ စာသားရိုက်ထည့်ခြင်းနှင့် ဖိုင်တင်ခြင်းများကို ပံ့ပိုးပေးပါသည်။",
      "developers": "ဖန်တီးသူများ",
      "version": "ဗားရှင်း",
      
      // History
      "searchHistory": "မှတ်တမ်းရှာရန်",
      "noHistory": "မှတ်တမ်းမရှိသေးပါ",
      "delete": "ဖျက်ရန်",
      "renameTitle": "ခေါင်းစဉ်ပြောင်းရန်",
      
      // Common
      "cancel": "မလုပ်တော့",
      "confirm": "အတည်ပြုရန်",
      "save": "သိမ်းရန်",
      "edit": "ပြင်ဆင်ရန်",
      "delete": "ဖျက်ရန်",
      "loading": "ခေတ္တစောင့်ပါ...",
      "error": "အမှား",
      "success": "အောင်မြင်ပါသည်",
      "pleaseWait": "ကျေးဇူးပြု၍ စောင့်ပါ...",
      "uploadFailed": "တင်ခြင်း မအောင်မြင်ပါ",
      "processingComplete": "လုပ်ဆောင်ပြီးပါပြီ",
    }
  },
  
  // Japanese
  ja: {
    translation: {
      "welcome": "MindLinkへようこそ",
      "email": "メールアドレス",
      "password": "パスワード",
      "forgotPassword": "パスワードをお忘れですか？",
      "signIn": "ログイン",
      "signUp": "新規登録",
      "createAccount": "アカウントを作成",
      "scan": "スキャン",
      "image": "画像",
      "text": "テキスト",
      "file": "ファイル",
      "history": "履歴",
      "settings": "設定",
      "profile": "プロフィール",
      "summarize": "要約",
      "answer": "回答を探す",
      "paraphrase": "言い換え",
      "explain": "理論の解説",
      "signOut": "ログアウト",
      "appearance": "外観",
      "language": "言語設定",
      "about": "アプリについて",
      "security": "セキュリティとプライバシー",
      "resultLanguage": "結果の言語",
      "saveAsImage": "画像として保存",
      "saveAsPDF": "PDFとして保存",
    }
  },
  
  // Korean
  ko: {
    translation: {
      "welcome": "MindLink에 오신 것을 환영합니다",
      "email": "이메일",
      "password": "비밀번호",
      "forgotPassword": "비밀번호를 잊으셨나요?",
      "signIn": "로그인",
      "signUp": "가입하기",
      "createAccount": "계정 만들기",
      "scan": "스캔",
      "image": "이미지",
      "text": "텍스트",
      "file": "파일",
      "history": "기록",
      "settings": "설정",
      "profile": "프로필",
      "summarize": "요약",
      "answer": "답변 찾기",
      "paraphrase": "다시 말하기",
      "explain": "이론 설명",
      "signOut": "로그아웃",
      "appearance": "외관",
      "language": "앱 언어",
      "about": "앱 정보",
      "security": "보안 및 개인정보",
      "resultLanguage": "결과 언어",
      "saveAsImage": "이미지로 저장",
      "saveAsPDF": "PDF로 저장",
    }
  },
  
  // Chinese (Simplified)
  zh: {
    translation: {
      "welcome": "欢迎使用MindLink",
      "email": "电子邮箱",
      "password": "密码",
      "forgotPassword": "忘记密码？",
      "signIn": "登录",
      "signUp": "注册",
      "createAccount": "创建账户",
      "scan": "扫描",
      "image": "图片",
      "text": "文本",
      "file": "文件",
      "history": "历史",
      "settings": "设置",
      "profile": "个人资料",
      "summarize": "总结",
      "answer": "查找答案",
      "paraphrase": "改述",
      "explain": "理论解释",
      "signOut": "登出",
      "appearance": "外观",
      "language": "应用语言",
      "about": "关于应用",
      "security": "安全与隐私",
      "resultLanguage": "结果语言",
      "saveAsImage": "保存为图片",
      "saveAsPDF": "保存为PDF",
    }
  },
  
  // Thai
  th: {
    translation: {
      "welcome": "ยินดีต้อนรับสู่ MindLink",
      "email": "อีเมล",
      "password": "รหัสผ่าน",
      "forgotPassword": "ลืมรหัสผ่าน?",
      "signIn": "เข้าสู่ระบบ",
      "signUp": "สมัครสมาชิก",
      "createAccount": "สร้างบัญชี",
      "scan": "สแกน",
      "image": "รูปภาพ",
      "text": "ข้อความ",
      "file": "ไฟล์",
      "history": "ประวัติ",
      "settings": "การตั้งค่า",
      "profile": "โปรไฟล์",
      "summarize": "สรุป",
      "answer": "ค้นหาคำตอบ",
      "paraphrase": "ถอดความ",
      "explain": "อธิบายทฤษฎี",
      "signOut": "ออกจากระบบ",
      "appearance": "รูปลักษณ์",
      "language": "ภาษาแอป",
      "about": "เกี่ยวกับแอป",
      "security": "ความปลอดภัยและความเป็นส่วนตัว",
      "resultLanguage": "ภาษาผลลัพธ์",
      "saveAsImage": "บันทึกเป็นรูปภาพ",
      "saveAsPDF": "บันทึกเป็น PDF",
    }
  },
  
  // Vietnamese
  vi: {
    translation: {
      "welcome": "Chào mừng đến với MindLink",
      "email": "Email",
      "password": "Mật khẩu",
      "forgotPassword": "Quên mật khẩu?",
      "signIn": "Đăng nhập",
      "signUp": "Đăng ký",
      "createAccount": "Tạo tài khoản",
      "scan": "Quét",
      "image": "Hình ảnh",
      "text": "Văn bản",
      "file": "Tệp",
      "history": "Lịch sử",
      "settings": "Cài đặt",
      "profile": "Hồ sơ",
      "summarize": "Tóm tắt",
      "answer": "Tìm câu trả lời",
      "paraphrase": "Diễn đạt lại",
      "explain": "Giải thích lý thuyết",
      "signOut": "Đăng xuất",
      "resultLanguage": "Ngôn ngữ kết quả",
      "saveAsImage": "Lưu dưới dạng hình ảnh",
      "saveAsPDF": "Lưu dưới dạng PDF",
    }
  },
  
  // Spanish
  es: {
    translation: {
      "welcome": "Bienvenido a MindLink",
      "email": "Correo electrónico",
      "password": "Contraseña",
      "forgotPassword": "¿Olvidaste tu contraseña?",
      "signIn": "Iniciar sesión",
      "signUp": "Registrarse",
      "createAccount": "Crear cuenta",
      "scan": "Escanear",
      "image": "Imagen",
      "text": "Texto",
      "file": "Archivo",
      "history": "Historial",
      "settings": "Configuración",
      "profile": "Perfil",
      "summarize": "Resumir",
      "answer": "Encontrar respuesta",
      "paraphrase": "Parafrasear",
      "explain": "Explicar teoría",
      "signOut": "Cerrar sesión",
      "resultLanguage": "Idioma de resultado",
      "saveAsImage": "Guardar como imagen",
      "saveAsPDF": "Guardar como PDF",
    }
  },
  
  // French
  fr: {
    translation: {
      "welcome": "Bienvenue sur MindLink",
      "email": "Email",
      "password": "Mot de passe",
      "forgotPassword": "Mot de passe oublié?",
      "signIn": "Se connecter",
      "signUp": "S'inscrire",
      "createAccount": "Créer un compte",
      "scan": "Scanner",
      "image": "Image",
      "text": "Texte",
      "file": "Fichier",
      "history": "Historique",
      "settings": "Paramètres",
      "profile": "Profil",
      "summarize": "Résumer",
      "answer": "Trouver la réponse",
      "paraphrase": "Paraphraser",
      "explain": "Expliquer la théorie",
      "signOut": "Se déconnecter",
      "resultLanguage": "Langue du résultat",
      "saveAsImage": "Enregistrer comme image",
      "saveAsPDF": "Enregistrer comme PDF",
    }
  },
  
  // German
  de: {
    translation: {
      "welcome": "Willkommen bei MindLink",
      "email": "E-Mail",
      "password": "Passwort",
      "forgotPassword": "Passwort vergessen?",
      "signIn": "Anmelden",
      "signUp": "Registrieren",
      "createAccount": "Konto erstellen",
      "scan": "Scannen",
      "image": "Bild",
      "text": "Text",
      "file": "Datei",
      "history": "Verlauf",
      "settings": "Einstellungen",
      "profile": "Profil",
      "summarize": "Zusammenfassen",
      "answer": "Antwort finden",
      "paraphrase": "Umschreiben",
      "explain": "Theorie erklären",
      "signOut": "Abmelden",
      "resultLanguage": "Ergebnissprache",
      "saveAsImage": "Als Bild speichern",
      "saveAsPDF": "Als PDF speichern",
    }
  },
  
  // Hindi
  hi: {
    translation: {
      "welcome": "MindLink में आपका स्वागत है",
      "email": "ईमेल",
      "password": "पासवर्ड",
      "forgotPassword": "पासवर्ड भूल गए?",
      "signIn": "साइन इन करें",
      "signUp": "साइन अप करें",
      "createAccount": "खाता बनाएं",
      "scan": "स्कैन",
      "image": "छवि",
      "text": "पाठ",
      "file": "फ़ाइल",
      "history": "इतिहास",
      "settings": "सेटिंग्स",
      "profile": "प्रोफ़ाइल",
      "summarize": "सारांश",
      "answer": "उत्तर खोजें",
      "paraphrase": "पुनः व्याख्या",
      "explain": "सिद्धांत समझाएं",
      "signOut": "साइन आउट",
      "resultLanguage": "परिणाम भाषा",
      "saveAsImage": "छवि के रूप में सहेजें",
      "saveAsPDF": "PDF के रूप में सहेजें",
    }
  },
  
  // Indonesian
  id: {
    translation: {
      "welcome": "Selamat datang di MindLink",
      "email": "Email",
      "password": "Kata sandi",
      "forgotPassword": "Lupa kata sandi?",
      "signIn": "Masuk",
      "signUp": "Daftar",
      "createAccount": "Buat akun",
      "scan": "Pindai",
      "image": "Gambar",
      "text": "Teks",
      "file": "Berkas",
      "history": "Riwayat",
      "settings": "Pengaturan",
      "profile": "Profil",
      "summarize": "Ringkas",
      "answer": "Cari jawaban",
      "paraphrase": "Parafrase",
      "explain": "Jelaskan teori",
      "signOut": "Keluar",
      "resultLanguage": "Bahasa hasil",
      "saveAsImage": "Simpan sebagai gambar",
      "saveAsPDF": "Simpan sebagai PDF",
    }
  },
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    lng: localStorage.getItem('i18nextLng') || 'en',
    interpolation: {
      escapeValue: false
    },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage']
    }
  });

export default i18n;
